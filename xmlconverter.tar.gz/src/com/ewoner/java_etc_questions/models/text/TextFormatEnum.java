package com.ewoner.java_etc_questions.models.text;


public enum TextFormatEnum {
    html,
    muddle_auto_format,
    plain_text,
    markdown,
    NONE;
         
}
