package com.ewoner.java_etc_questions.models.text;


public enum FeedbackTypeEnum {
    general,
    correct,
    partial,
    incorrect,
    answer;
}
