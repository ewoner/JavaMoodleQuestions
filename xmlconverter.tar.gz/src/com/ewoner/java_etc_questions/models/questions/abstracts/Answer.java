package com.ewoner.java_etc_questions.models.questions.abstracts;

/**
 *
 * @author student
 */
public class Answer {
    
}
