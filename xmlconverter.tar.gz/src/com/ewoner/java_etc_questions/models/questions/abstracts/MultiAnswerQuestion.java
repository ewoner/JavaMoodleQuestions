package com.ewoner.java_etc_questions.models.questions.abstracts;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 *
 * @author student
 * @param <T>
 */
public class MultiAnswerQuestion<T extends Answer> extends Question {

    private List<T> answers;
    private boolean shuffleAnswers;
    private String correctFB;
    private String partiallyFB;
    private String incorrectFB;
    private boolean showCorrect;

    private MultiAnswerQuestion() {
        this( QuestionTypeEnum.NONE, 0, "QUESTION NAME", "QUESTION TEXT", "GENERALFEEDBACK TEXT" );
    }

    public MultiAnswerQuestion( QuestionTypeEnum type ) {
        this( type, 0, "QUESTION NAME", "QUESTION TEXT", "GENERALFEEDBACK TEXT" );
    }

    public MultiAnswerQuestion( QuestionTypeEnum type, int id ) {
        this( type, id, "QUESTION NAME", "QUESTION TEXT", "GENERALFEEDBACK TEXT" );
    }

    public MultiAnswerQuestion( QuestionTypeEnum type, int id, String name, String text ) {
        this( type, id, name, text, "" );
    }

    public MultiAnswerQuestion( QuestionTypeEnum type, String name, String text ) {
        this( type, 0, name, text, "" );
    }

    public MultiAnswerQuestion( QuestionTypeEnum type, String name, String text, String generalFB ) {
        this( type, 0, name, text, generalFB );
    }

    public MultiAnswerQuestion( QuestionTypeEnum type, int id, String name, String text, String generalFB ) {
        super( type, id, name, text, generalFB );
        answers = new ArrayList<>();
        this.shuffleAnswers = true;
        this.showCorrect = true;
        correctFB = "Your answer is correct.";
        incorrectFB = "Your answer is incorrect.";
        partiallyFB = "Your answer is partially correct.";
    }

    /**
     * @return the shuffleAnswers
     */
    public boolean isShuffleAnswers() {
        return shuffleAnswers;
    }

    /**
     * @param shuffleAnswers the shuffleAnswers to set
     */
    public void setShuffleAnswers( boolean shuffleAnswers ) {
        this.shuffleAnswers = shuffleAnswers;
    }

    /**
     * @return the correctFB
     */
    public String getCorrectFB() {
        return correctFB;
    }

    /**
     * @param correctFB the correctFB to set
     */
    public void setCorrectFB( String correctFB ) {
        this.correctFB = correctFB;
    }

    /**
     * @return the incorrectFB
     */
    public String getIncorrectFB() {
        return incorrectFB;
    }

    /**
     * @param incorrectFB the incorrectFB to set
     */
    public void setIncorrectFB( String incorrectFB ) {
        this.incorrectFB = incorrectFB;
    }

    /**
     * @return the showCorrect
     */
    public boolean isShowCorrect() {
        return showCorrect;
    }

    /**
     * @param showCorrect the showCorrect to set
     */
    public void setShowCorrect( boolean showCorrect ) {
        this.showCorrect = showCorrect;
    }

    /**
     * @return the partiallyFB
     */
    public String getPartiallyFB() {
        return partiallyFB;
    }

    /**
     * @param partiallyFB the partiallyFB to set
     */
    public void setPartiallyFB( String partiallyFB ) {
        this.partiallyFB = partiallyFB;
    }

    public boolean add( T answer ) {
        return answers.add( answer );
    }

    public boolean addAll( Collection<? extends T> c ) {
        return answers.addAll( c );
    }

    public void clear() {
        answers.clear();
    }

    public T get( int index ) {
        return answers.get( index );
    }

    public boolean isEmpty() {
        return answers.isEmpty();
    }

    public T remove( int index ) {
        return answers.remove( index );
    }

    public int size() {
        return answers.size();
    }

    public List<T> toList() {
        return new ArrayList<>( answers );
    }

    public T[] toArray() {
        T[] array = (T[]) new Object[0];
        return answers.toArray( array );
    }
}
