package com.ewoner.java_etc_questions.models.questions;

import com.ewoner.java_etc_questions.models.questions.abstracts.Question;
import com.ewoner.java_etc_questions.models.questions.abstracts.QuestionTypeEnum;


public class ShortAnswer extends Question {
    private String correctFB;
    private boolean usecase;
    
    public ShortAnswer() {
        this( 0, "QUESTION NAME", "QUESTION TEXT", "GENERALFEEDBACK TEXT" );
    }

    

    public ShortAnswer( QuestionTypeEnum type, int id ) {
        this(  id, "QUESTION NAME", "QUESTION TEXT", "GENERALFEEDBACK TEXT" );
    }

    public ShortAnswer( QuestionTypeEnum type, int id, String name, String text ) {
        this(  id, name, text, "" );
    }

    public ShortAnswer( QuestionTypeEnum type, String name, String text ) {
        this(  0, name, text, "" );
    }

    public ShortAnswer( QuestionTypeEnum type, String name, String text, String generalFB ) {
        this(  0, name, text, generalFB );
    }

    public ShortAnswer( int id, String name, String text, String generalFB ) {
        super( QuestionTypeEnum.ShortAnswer, id, name, text, generalFB);
        correctFB = "";
        usecase = false;
    }

    /**
     * @return the correctFB
     */
    public String getCorrectFB() {
        return correctFB;
    }

    /**
     * @param correctFB the correctFB to set
     */
    public void setCorrectFB( String correctFB ) {
        this.correctFB = correctFB;
    }

    /**
     * @return the usecase
     */
    public boolean isUsecase() {
        return usecase;
    }

    /**
     * @param usecase the usecase to set
     */
    public void setUsecase( boolean usecase ) {
        this.usecase = usecase;
    }
}
