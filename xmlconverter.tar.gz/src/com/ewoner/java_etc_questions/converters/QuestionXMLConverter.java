package com.ewoner.java_etc_questions.converters;

import com.ewoner.java_etc_questions.models.questions.MultiChoice;
import com.ewoner.java_etc_questions.models.questions.MultiChoiceSet;
import com.ewoner.java_etc_questions.models.questions.ShortAnswer;
import com.ewoner.java_etc_questions.models.questions.TrueFalse;
import com.ewoner.java_etc_questions.models.questions.abstracts.AnswerNumberEnum;
import com.ewoner.java_etc_questions.models.questions.abstracts.MultiAnswerQuestion;
import com.ewoner.java_etc_questions.models.questions.abstracts.Question;
import com.ewoner.java_etc_questions.models.questions.abstracts.QuestionTypeEnum;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.namespace.QName;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;

public class QuestionXMLConverter {

    private XMLEventReader reader;
    private String filename;
    private File file;

    public List<Question> parseXMLFile() {
        List<Question> questions = new ArrayList<>();
        Set<String> attTypesNotSupported = new TreeSet<>();
        if ( reader != null ) {
            try {
                while ( reader.hasNext() ) {
                    var peeked = reader.peek();
                    if ( peeked.isStartElement() ) {
                        if ( peeked.asStartElement().getName().getLocalPart().equals( "question" ) ) {
                            String attType = reader.nextEvent().asStartElement().getAttributeByName( new QName( "type" ) ).getValue();
                            switch ( attType ) {
                                case "category":
                                    Logger.getLogger( QuestionXMLConverter.class.getName() ).log( Level.INFO, "Parsing not yet supported: {0}", attType );
                                    attTypesNotSupported.add( attType );
                                    break;
                                case "truefalse":
                                    questions.add( parseXMLQuestion( QuestionTypeEnum.TrueFalse ) );
                                    break;
                                case "multichoice":
                                    questions.add( parseXMLQuestion( QuestionTypeEnum.MultipleChoice ) );
                                    break;
                                case "multichoiceset":
                                    questions.add( parseXMLQuestion( QuestionTypeEnum.MultipleChoice ) );
                                    break;
                                default:
                                    Logger.getLogger( QuestionXMLConverter.class.getName() ).log( Level.INFO, "Parsing not yet supported: {0}", attType );
                                    attTypesNotSupported.add( attType );
                                    break;
//                                    Logger.getLogger( QuestionXMLConverter.class.getName() ).log( Level.SEVERE, "Unknown Question type: {0}", attType );
//                                    break;
                            }
                        }
                    }
                    reader.next();

                }
            } catch ( XMLStreamException ex ) {

            }
        } else {
            return null;
        }
        System.out.println( "------------------------------------------------" );
        for ( String att : attTypesNotSupported ) {
            System.out.println( att );
        }
        System.out.println( "------------------------------------------------" );
        return questions;
    }

        public QuestionXMLConverter() {
        this( null );
    }

    public QuestionXMLConverter( String filename ) {
        this.filename = filename;
        setReader();
    }

    private void setReader() {
        if ( filename == null || filename.isBlank() ) {
            this.file = null;
            this.reader = null;
        } else {
            file = new File( filename );
            if ( file.exists() ) {
                XMLInputFactory factory = XMLInputFactory.newInstance();
                try {
                    reader = factory.createXMLEventReader( new FileInputStream( file ) );
                } catch ( FileNotFoundException | XMLStreamException ex ) {
                    Logger.getLogger( QuestionXMLConverter.class.getName() ).log( Level.SEVERE, null, ex );
                }
            }
        }
    }

    private String toXML( Question question ) {
        return "xml";
    }

    public String toXML( MultiChoice question ) {
        return "xml";
    }

    public String toXML( MultiChoiceSet question ) {
        return "xml";
    }

    private Question parseXMLQuestion( QuestionTypeEnum qType ) {
        Question q = null;
        MultiAnswerQuestion maq = null;
        try {
            switch ( qType ) {
                case TrueFalse:
                    q = new TrueFalse();
                    break;
                case MultipleChoice:
                    q = new MultiChoice();
                    maq = ( MultiAnswerQuestion ) q;
                    break;
                case MultipleChoice_AllorNothing:
                    q = new MultiChoiceSet();
                    maq = ( MultiAnswerQuestion ) q;
                    break;
            }
            if ( q == null ) {
                Logger.getLogger( QuestionXMLConverter.class.getName() ).log( Level.SEVERE, "Question type not reconized in paseXMLQuestion()." );
                return null;
            }
            XMLEvent event = reader.nextEvent();
            while ( !( event.isEndElement() && event.asEndElement().getName().getLocalPart().equals( "question" ) ) ) {
                if ( event.isStartElement() ) {
                    StartElement ele = event.asStartElement();
                    switch ( ele.getName().getLocalPart() ) {
                        case "name":
                            q.setName( parseTextBlock( ele ) );
                            break;
                        case "questiontext":
                            q.setText( parseTextBlock( ele ) );
                            break;
                        case "generalfeedback":
                            q.setGeneralFB( parseTextBlock( ele ) );
                            break;
                        case "defaultgrade":
                            q.setDefaultGrade( parseNumberData() );
                            break;
                        case "penalty":
                            q.setPenalty( parseNumberData() );
                            break;
                        case "hidden":
                            q.setHidden( parseBooleanData() );
                            break;
                        case "idnumber":
                            q.setIdNumber( parseStringData() );
                            break;
                        /* ======> MULTIANSWER QUESTIONS ONLY <====================================== */
                        case "shuffleanswers":
                            maq.setShuffleAnswers( parseBooleanData() );
                            break;
                        case "pariallycorrectfeedback":
                            maq.setCorrectFB( parseTextBlock( ele ) );
                            break;
                        case "correctfeedback":
                            if ( q.getType() == QuestionTypeEnum.MultipleChoice || q.getType() == QuestionTypeEnum.MultipleChoice_AllorNothing ) {
                                maq.setCorrectFB( parseTextBlock( ele ) );
                            } else if ( q.getType() == QuestionTypeEnum.ShortAnswer ) {
                                ShortAnswer saq = ( ShortAnswer ) q;
                                saq.setCorrectFB( parseTextBlock( ele ) );
                            }
                            break;
                        case "incorrectfeedback":
                            maq.setIncorrectFB( parseTextBlock( ele ) );
                            break;
                        case "shownumcorrect":
                            maq.setShowCorrect( parseBooleanData() );
                            break;
                        /* ======> MULTICHOICESET QUESTIONS ONLY <====================================== */
                        case "answernumbering":
                            MultiChoiceSet msq = ( MultiChoiceSet ) maq;
                            try {
                                msq.setNumbering( AnswerNumberEnum.valueOf( parseStringData() ) );
                            } catch ( IllegalArgumentException ex ) {
                                msq.setNumbering( AnswerNumberEnum.none );
                                Logger.getLogger( QuestionXMLConverter.class.getName() ).log( Level.WARNING, "AnswerNumbering not type not excepts, set to 'non'" );
                            }
                            break;
                        case "showstandardinstruction":
                            msq = ( MultiChoiceSet ) maq;
                            msq.setShowInstructions( parseBooleanData() );
                        /* ======> MULTICHOICE QUESTION ONLY <======================================= */
                        case "single":
                            MultiChoice mcq = ( MultiChoice ) q;
                            mcq.setSingle( parseBooleanData() );
                            break;
                        /* ======> SHORTANSWER QUESTION ONLY <======================================= */
                        case "usecase":

                            break;
                        /* ========================================================================== */
                    }
                }
                event = reader.nextEvent();
            }
        } catch ( XMLStreamException ex ) {
            Logger.getLogger( QuestionXMLConverter.class.getName() ).log( Level.SEVERE, null, ex );
        }
        return q;
    }

    private String parseTextBlock( StartElement ele ) throws XMLStreamException {
        String rv = "";
        XMLEvent event;
        /*TextFormatEnum format;
        try {
            format = TextFormatEnum.valueOf( ele.getAttributeByName( new QName( "format" ) ).getValue() );
        } catch ( NullPointerException e ) {
            format = TextFormatEnum.NONE;
        }*/
        reader.nextTag();
        event = reader.nextEvent();
        if ( event.isCharacters() ) {
            rv = event.asCharacters().getData();
        }
        return rv;
    }

    private double parseNumberData() throws XMLStreamException {
        double data;
        try {
            data = Double.parseDouble( reader.nextEvent().asCharacters().getData() );
        } catch ( NumberFormatException | NullPointerException ex ) {
            data = 0.0;
            Logger.getLogger( QuestionXMLConverter.class.getName() ).log( Level.WARNING, "Cannot parse a number/double, using 0.0" );
        }
        return data;
    }

    private boolean parseBooleanData() throws XMLStreamException {
        boolean rv;
        int asInt;
        String data = reader.nextEvent().asCharacters().getData();
        try {
            asInt = Integer.parseInt( data );
        } catch ( NumberFormatException | NullPointerException ex ) {
            Logger.getLogger( QuestionXMLConverter.class.getName() ).log( Level.INFO, "Parsing Boolean is not 0/1 formated." );
            asInt = -1;
        }
        if ( asInt == -1 ) {
            try {
                rv = Boolean.parseBoolean( data );
            } catch ( NumberFormatException | NullPointerException ex ) {
                rv = true;
                Logger.getLogger( QuestionXMLConverter.class.getName() ).log( Level.WARNING, "Cannot parse a Boolean, using TRUE" );
            }
            return rv;
        } else {
            return ( 0 != asInt );
        }
    }

    private String parseStringData() throws XMLStreamException {
        String data = "";
        XMLEvent event = reader.nextEvent();
        if ( event.isCharacters() ) {
            data = event.asCharacters().getData();
        }
        return data;
    }
}
