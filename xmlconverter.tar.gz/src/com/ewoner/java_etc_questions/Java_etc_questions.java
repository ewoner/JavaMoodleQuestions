package com.ewoner.java_etc_questions;

import com.ewoner.java_etc_questions.converters.QuestionXMLConverter;
import com.ewoner.java_etc_questions.models.questions.abstracts.Question;
import java.io.File;
import java.util.List;

/**
 *
 * @author student
 */
public class Java_etc_questions {

    /**
     * @param args the command line arguments
     */
    public static void main( String[] args ) {
        File file = new File( "src/test.xml" );
        QuestionXMLConverter qc = new QuestionXMLConverter( file.getAbsolutePath() );
        List<Question> questions = qc.parseXMLFile();
        System.out.println( "It worked!\n" + file.getAbsolutePath() );
        System.out.println("Questions is size: " + questions.size());
    }

}
