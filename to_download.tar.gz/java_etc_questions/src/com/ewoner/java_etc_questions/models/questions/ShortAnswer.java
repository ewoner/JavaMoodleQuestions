package com.ewoner.java_etc_questions.models.questions;

import com.ewoner.java_etc_questions.models.questions.abstracts.Answer;
import com.ewoner.java_etc_questions.models.questions.abstracts.MultiAnswerContainer;
import com.ewoner.java_etc_questions.models.questions.abstracts.Question;
import com.ewoner.java_etc_questions.models.questions.abstracts.QuestionTypeEnum;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class ShortAnswer extends Question implements MultiAnswerContainer<Answer> {

    private boolean usecase;
    List<Answer> answers;

    public ShortAnswer() {
        this( 0, "QUESTION NAME", "QUESTION TEXT", "GENERALFEEDBACK TEXT" );
    }

    public ShortAnswer( QuestionTypeEnum type, int id ) {
        this( id, "QUESTION NAME", "QUESTION TEXT", "GENERALFEEDBACK TEXT" );
    }

    public ShortAnswer( QuestionTypeEnum type, int id, String name, String text ) {
        this( id, name, text, "" );
    }

    public ShortAnswer( QuestionTypeEnum type, String name, String text ) {
        this( 0, name, text, "" );
    }

    public ShortAnswer( QuestionTypeEnum type, String name, String text, String generalFB ) {
        this( 0, name, text, generalFB );
    }

    public ShortAnswer( int id, String name, String text, String generalFB ) {
        super( QuestionTypeEnum.ShortAnswer, id, name, text, generalFB );
        answers = new ArrayList<>();
        usecase = false;
    }

    /**
     * @return the usecase
     */
    public boolean isUsecase() {
        return usecase;
    }

    /**
     * @param usecase the usecase to set
     */
    public void setUsecase( boolean usecase ) {
        this.usecase = usecase;
    }

    @Override
    public boolean addAnswer( Answer answer ) {
        return answers.add( answer );
    }

    @Override
    public boolean addAllAnswers( Collection<? extends Answer> c ) {
        return answers.addAll( c );
    }

    @Override
    public void clear() {
        answers.clear();
    }

    @Override
    public Answer getAnswer( int index ) {
        return answers.get( index );
    }

    @Override
    public boolean hasAnswers() {
        return answers.isEmpty();
    }

    @Override
    public Answer removeAnswer( int index ) {
        return answers.remove( index );
    }

    @Override
    public int numAnswers() {
        return answers.size();
    }

    @Override
    public List<Answer> AnswersToList() {
        return new ArrayList<>( answers );
    }

    @Override
    public Answer[] answersToArray() {
        Answer[] array = ( Answer[] ) new Object[ 0 ];
        return answers.toArray( array );
    }
}
