package com.ewoner.java_etc_questions.models.questions.abstracts;

/**
 *
 * @author student
 */
public class Answer {

    private String text;
    private double fraction;
    private String feedback;

    public Answer(){
        this("", 100.0, "");
    }
    public Answer(String text ){
        this(text, 100.0, "");
    }
    public Answer (String text, double fraction ){
        this( text, fraction , "" );
    }
    public Answer( String text, double fraction, String feedback ){
        this.text = text;
        this.fraction = fraction;
        this.feedback = feedback;
    }

    /**
     * @return the text
     */
    public String getText() {
        return text;
    }

    /**
     * @param text the text to set
     */
    public void setText( String text ) {
        this.text = text;
    }

    /**
     * @return the fraction
     */
    public double getFraction() {
        return fraction;
    }

    /**
     * @param fraction the fraction to set
     */
    public void setFraction( double fraction ) {
        this.fraction = fraction;
    }

    /**
     * @return the feedback
     */
    public String getFeedback() {
        return feedback;
    }

    /**
     * @param feedback the feedback to set
     */
    public void setFeedback( String feedback ) {
        this.feedback = feedback;
    }

}