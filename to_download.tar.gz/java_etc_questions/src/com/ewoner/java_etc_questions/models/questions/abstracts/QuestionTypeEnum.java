package com.ewoner.java_etc_questions.models.questions.abstracts;


public enum QuestionTypeEnum {
    MultipleChoice,
    MultipleChoice_AllorNothing  ("multichoiceset"),
    TrueFalse,
    ShortAnswer,
    CodeRunner,
    GapSelect,
    
    Numerical_ShortAnser ("numerical"),
    Calculated,
    Calculated_MultipleChoice ("calculatedmulti"),
    Matching ("ddmatch"),
    DragAndDrop("ddwtos"),
    Essay,
    Close,
    DescriptionResponse,
    RandomMathing("randommatch"),
    NONE;
    
    private final String xmlString;
    
    private QuestionTypeEnum() {
        this.xmlString = this.name().toLowerCase();
    }
    
    private QuestionTypeEnum( String xmlString ) {
        this.xmlString = xmlString;
    }
    
    public String asXMLString(){
        return xmlString;
    }
}
