package com.ewoner.java_etc_questions.models.questions.abstracts;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 *
 * @author student
 * @param <T>
 */
public class MultiAnswerQuestion<T extends Answer> extends Question implements MultiAnswerContainer<T> {

    private List<T> answers;
    private boolean shuffleAnswers;
    private String correctFB;
    private String partiallyFB;
    private String incorrectFB;
    private boolean showCorrect;

    private MultiAnswerQuestion() {
        this( QuestionTypeEnum.NONE, 0, "QUESTION NAME", "QUESTION TEXT", "GENERALFEEDBACK TEXT" );
    }

    public MultiAnswerQuestion( QuestionTypeEnum type ) {
        this( type, 0, "QUESTION NAME", "QUESTION TEXT", "GENERALFEEDBACK TEXT" );
    }

    public MultiAnswerQuestion( QuestionTypeEnum type, int id ) {
        this( type, id, "QUESTION NAME", "QUESTION TEXT", "GENERALFEEDBACK TEXT" );
    }

    public MultiAnswerQuestion( QuestionTypeEnum type, int id, String name, String text ) {
        this( type, id, name, text, "" );
    }

    public MultiAnswerQuestion( QuestionTypeEnum type, String name, String text ) {
        this( type, 0, name, text, "" );
    }

    public MultiAnswerQuestion( QuestionTypeEnum type, String name, String text, String generalFB ) {
        this( type, 0, name, text, generalFB );
    }

    public MultiAnswerQuestion( QuestionTypeEnum type, int id, String name, String text, String generalFB ) {
        super( type, id, name, text, generalFB );
        answers = new ArrayList<>();
        this.shuffleAnswers = true;
        this.showCorrect = true;
        correctFB = "Your answer is correct.";
        incorrectFB = "Your answer is incorrect.";
        partiallyFB = "Your answer is partially correct.";
    }

    /**
     * @return the shuffleAnswers
     */
    public boolean isShuffleAnswers() {
        return shuffleAnswers;
    }

    /**
     * @param shuffleAnswers the shuffleAnswers to set
     */
    public void setShuffleAnswers( boolean shuffleAnswers ) {
        this.shuffleAnswers = shuffleAnswers;
    }

    /**
     * @return the correctFB
     */
    public String getCorrectFB() {
        return correctFB;
    }

    /**
     * @param correctFB the correctFB to set
     */
    public void setCorrectFB( String correctFB ) {
        this.correctFB = correctFB;
    }

    /**
     * @return the incorrectFB
     */
    public String getIncorrectFB() {
        return incorrectFB;
    }

    /**
     * @param incorrectFB the incorrectFB to set
     */
    public void setIncorrectFB( String incorrectFB ) {
        this.incorrectFB = incorrectFB;
    }

    /**
     * @return the showCorrect
     */
    public boolean isShowCorrect() {
        return showCorrect;
    }

    /**
     * @param showCorrect the showCorrect to set
     */
    public void setShowCorrect( boolean showCorrect ) {
        this.showCorrect = showCorrect;
    }

    /**
     * @return the partiallyFB
     */
    public String getPartiallyFB() {
        return partiallyFB;
    }

    /**
     * @param partiallyFB the partiallyFB to set
     */
    public void setPartiallyFB( String partiallyFB ) {
        this.partiallyFB = partiallyFB;
    }

    @Override
    public boolean addAnswer( T answer ) {
        return answers.add( answer );
    }

    @Override
    public boolean addAllAnswers( Collection<? extends T> c ) {
        return answers.addAll( c );
    }

    @Override
    public void clear() {
        answers.clear();
    }

    @Override
    public T getAnswer( int index ) {
        return answers.get( index );
    }

    @Override
    public boolean hasAnswers() {
        return answers.isEmpty() == false;
    }

    @Override
    public T removeAnswer( int index ) {
        return answers.remove( index );
    }

    @Override
    public int numAnswers() {
        return answers.size();
    }

    @Override
    public List<T> AnswersToList() {
        return new ArrayList<>( answers );
    }

    @Override
    public T[] answersToArray() {
        T[] array = (T[]) new Object[0];
        return answers.toArray( array );
    }
}
