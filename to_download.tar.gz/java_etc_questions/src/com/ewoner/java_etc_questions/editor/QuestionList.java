/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ewoner.java_etc_questions.editor;

import com.ewoner.java_etc_questions.models.questions.abstracts.Question;
import java.util.ArrayList;

/**
 * Created on $(date), $(time)
 *
 * @author Brion
 * @param <Q>
 */
public class QuestionList<Q extends Question> {

    ArrayList<Q> questionList;

    public QuestionList() {
        questionList = new ArrayList<>();
    }

    public Q[] getList() {
        @SuppressWarnings( "unchecked" )
        Q a[] = ( Q[] ) ( new Question[ questionList.size() ] );
        questionList.toArray( a );
        return a;
    }

    public int indexOf( Q question ) {
        return questionList.indexOf( question );
    }

    public int size() {
        return questionList.size();
    }

    public void add( Q question ) {
        for ( var m : questionList ) {
            if ( m.equals( question ) ) {
                return;
            }
        }
        questionList.add( question );
    }

}
