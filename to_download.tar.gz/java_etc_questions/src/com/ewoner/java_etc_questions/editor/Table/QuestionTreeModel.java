/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ewoner.java_etc_questions.editor.Table;

import com.ewoner.java_etc_questions.converters.QuestionCSVConverter;
import com.ewoner.java_etc_questions.editor.QuestionList;
import com.ewoner.java_etc_questions.models.questions.abstracts.Question;
import javax.swing.table.DefaultTableModel;

/**
 * Created on $(date), $(time)
 *
 * @author Brion
 * @param <Q>
 */
public class QuestionTreeModel<Q extends Question> extends DefaultTableModel {

    QuestionList<Q> questionList;
    Object[][] data;
    String[] columnNames;

    public QuestionTreeModel( QuestionList<Q> rows ) {
        questionList = rows;
        QuestionCSVConverter csvanator = new QuestionCSVConverter();
        Q question = null;
        String columns = csvanator.getCSVHeader( question );
        columnNames = columns.split( "\",\"" );
        for ( int index = 0; index < columnNames.length; index++ ) {
            columnNames[ index ] = columnNames[ index ].replaceAll( "\"", "" );
        }
        data = new Object[ questionList.size() ][ columnNames.length ];
        updateData();
        setDataVector( data, columnNames );

    }

    public void updateRows() {
        updateData();
        setDataVector( data, columnNames );
    }

    private void updateData() {
/*        int index;
        data = new Object[ questionList.size() ][ columnNames.length ];
        /*for ( Q mail : questionList.getList() ) {
            index = questionList.indexOf( mail );
            data[ index ][ 0 ] = mail.getEmailNumber();
            data[ index ][ 1 ] = mail.getSender();
            data[ index ][ 2 ] = mail.getSubject();
            data[ index ][ 3 ] = mail.getSentDate();
            data[ index ][ 4 ] = mail.getVendor();
            data[ index ][ 5 ] = mail.getItem();
            data[ index ][ 6 ] = mail.getBuyer();
            data[ index ][ 7 ] = mail.getCredits();
            data[ index ][ 8 ] = mail.getLocation();
            data[ index ][ 9 ] = mail.getBody();
        }*/
    }
}
