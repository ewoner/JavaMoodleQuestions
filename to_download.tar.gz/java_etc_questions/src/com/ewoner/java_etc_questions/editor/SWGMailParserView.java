/*
 * SWGMailParserView.java
 */
package com.ewoner.java_etc_questions.editor;
/*
import com.ewoner.java_etc_questions.editor.Table.SWGMailTreeModel;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import javax.swing.Timer;
import javax.swing.Icon;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.TableRowSorter;

/**
 * The application's main frame.
 */
public class SWGMailParserView  {
/*
    private File[] selectedFiles;
    private SWGMailList mailList;
    private SWGMailTreeModel TreeModel;

    public SWGMailParserView( SingleFrameApplication app ) {
        super( app );
        FileNameExtensionFilter MailFilter = new FileNameExtensionFilter( "Mail files", "mail" );
        mailList = new SWGMailList();
        TreeModel = new SWGMailTreeModel( mailList );
        initComponents();
        mailTable.setRowSorter( new TableRowSorter( TreeModel ) );

        openFileChooser.setFileFilter( MailFilter );
        FileNameExtensionFilter CSVFilter = new FileNameExtensionFilter( "CSV files", "csv" );
        saveFileChooser.setFileFilter( CSVFilter );

        // status bar initialization - message timeout, idle icon and busy animation, etc
        ResourceMap resourceMap = getResourceMap();
        int messageTimeout = resourceMap.getInteger( "StatusBar.messageTimeout" );
        messageTimer = new Timer( messageTimeout, new ActionListener() {

            public void actionPerformed( ActionEvent e ) {
                statusMessageLabel.setText( "" );
            }
        } );
        messageTimer.setRepeats( false );
        int busyAnimationRate = resourceMap.getInteger( "StatusBar.busyAnimationRate" );
        for ( int i = 0; i < busyIcons.length; i++ ) {
            busyIcons[ i ] = resourceMap.getIcon( "StatusBar.busyIcons[" + i + "]" );
        }
        busyIconTimer = new Timer( busyAnimationRate, new ActionListener() {

            public void actionPerformed( ActionEvent e ) {
                busyIconIndex = ( busyIconIndex + 1 ) % busyIcons.length;
                statusAnimationLabel.setIcon( busyIcons[ busyIconIndex ] );
            }
        } );
        idleIcon = resourceMap.getIcon( "StatusBar.idleIcon" );
        statusAnimationLabel.setIcon( idleIcon );
        progressBar.setVisible( false );

        // connecting action tasks to status bar via TaskMonitor
        TaskMonitor taskMonitor = new TaskMonitor( getApplication().getContext() );
        taskMonitor.addPropertyChangeListener( new java.beans.PropertyChangeListener() {

            public void propertyChange( java.beans.PropertyChangeEvent evt ) {
                String propertyName = evt.getPropertyName();
                if ( "started".equals( propertyName ) ) {
                    if ( !busyIconTimer.isRunning() ) {
                        statusAnimationLabel.setIcon( busyIcons[ 0 ] );
                        busyIconIndex = 0;
                        busyIconTimer.start();
                    }
                    progressBar.setVisible( true );
                    progressBar.setIndeterminate( true );
                } else if ( "done".equals( propertyName ) ) {
                    busyIconTimer.stop();
                    statusAnimationLabel.setIcon( idleIcon );
                    progressBar.setVisible( false );
                    progressBar.setValue( 0 );
                } else if ( "message".equals( propertyName ) ) {
                    String text = ( String ) ( evt.getNewValue() );
                    statusMessageLabel.setText( ( text == null ) ? "" : text );
                    messageTimer.restart();
                } else if ( "progress".equals( propertyName ) ) {
                    int value = ( Integer ) ( evt.getNewValue() );
                    progressBar.setVisible( true );
                    progressBar.setIndeterminate( false );
                    progressBar.setValue( value );
                }
            }
        } );
    }

    @Action
    public void exportCSVAction() {
        File SaveFile;
        BufferedWriter bw = null;
        try {
            int returnVal = saveFileChooser.showSaveDialog( mainPanel );
            if ( returnVal == JFileChooser.APPROVE_OPTION ) {
                String fileName = saveFileChooser.getSelectedFile().getName();
                if ( !fileName.endsWith( ".csv" ) ) {
                    fileName = fileName + ".csv";
                }
                SaveFile = new File( saveFileChooser.getSelectedFile().getPath() + ".csv" );
                if ( SaveFile.length() > 0 ) {
                    if ( JOptionPane.NO_OPTION == JOptionPane.showConfirmDialog( mainPanel, "Are you sure you want to overwirte this file.  Data loss may resault.", "Overwrite File", JOptionPane.YES_NO_OPTION ) ) {
                        return;
                    } else {
                        bw = new BufferedWriter( new FileWriter( SaveFile ) );
                        SWGMail.writeHeader( bw, ',' );
                        //bw.write("\r\n");
                        for ( SWGMail mail : mailList.getList() ) {
                            mail.write( bw, ',' );
                            //bw.write("\r\n");
                        }
                    }
                } else {//SaveFile.createNewFile();
                    bw = new BufferedWriter( new FileWriter( SaveFile ) );
                    SWGMail.writeHeader( bw, ',' );
                    //bw.write("\r\n");
                    for ( SWGMail mail : mailList.getList() ) {
                        mail.write( bw, ',' );
                        //bw.write("\r\n");
                    }
                }
            }
        } catch ( FileNotFoundException ex ) {
            Logger.getLogger( SWGMailParserView.class.getName() ).log( Level.SEVERE, null, ex );
        } catch ( IOException ex ) {
            Logger.getLogger( SWGMailParserView.class.getName() ).log( Level.SEVERE, null, ex );
        } finally {
            try {
                if ( bw != null ) {
                    bw.flush();
                    bw.close();
                }
            } catch ( IOException ex ) {
                Logger.getLogger( SWGMailParserView.class.getName() ).log( Level.SEVERE, null, ex );
            }
        }
    }

    @Action
    public void opemMenuAction() {
        boolean changed = false;
        try {
            int returnVal = openFileChooser.showOpenDialog( mainPanel );
            if ( returnVal == JFileChooser.APPROVE_OPTION ) {
                selectedFiles = openFileChooser.getSelectedFiles();
                for ( File f : selectedFiles ) {
                    if ( f.isDirectory() ) {
                        for ( File f2 : f.listFiles() ) {
                            if ( f2.getName().endsWith( ".mail" ) ) {
                                mailList.add( new SWGMail( f2 ) );
                                changed = true;
                            }

                        }
                    } else if ( f.getName().endsWith( ".mail" ) ) {
                        mailList.add( new SWGMail( f ) );
                        changed = true;
                    }

                }

            }
        } catch ( FileNotFoundException ex ) {
            Logger.getLogger( SWGMailParserView.class.getName() ).log( Level.SEVERE, null, ex );
        } catch ( IOException ex ) {
            Logger.getLogger( SWGMailParserView.class.getName() ).log( Level.SEVERE, null, ex );
        }
        if ( changed ) {
            TreeModel.updateRows();
        }

    }

    @Action
    public void showAboutBox() {
        if ( aboutBox == null ) {
            JFrame mainFrame = SWGMailParserApp.getApplication().getMainFrame();
            aboutBox
                    = new SWGMailParserAboutBox( mainFrame );
            aboutBox.setLocationRelativeTo( mainFrame );
        }

        SWGMailParserApp.getApplication().show( aboutBox );
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    /*
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        mainPanel = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        mailTable = new javax.swing.JTable();
        menuBar = new javax.swing.JMenuBar();
        javax.swing.JMenu fileMenu = new javax.swing.JMenu();
        openMenuItem = new javax.swing.JMenuItem();
        javax.swing.JMenuItem exitMenuItem = new javax.swing.JMenuItem();
        exportMenu = new javax.swing.JMenu();
        exportCVSMenuItem = new javax.swing.JMenuItem();
        javax.swing.JMenu helpMenu = new javax.swing.JMenu();
        javax.swing.JMenuItem aboutMenuItem = new javax.swing.JMenuItem();
        statusPanel = new javax.swing.JPanel();
        javax.swing.JSeparator statusPanelSeparator = new javax.swing.JSeparator();
        statusMessageLabel = new javax.swing.JLabel();
        statusAnimationLabel = new javax.swing.JLabel();
        progressBar = new javax.swing.JProgressBar();
        openFileChooser = new javax.swing.JFileChooser();
        saveFileChooser = new javax.swing.JFileChooser();

        mainPanel.setName("mainPanel"); // NOI18N

        jScrollPane1.setName("jScrollPane1"); // NOI18N

        mailTable.setModel(TreeModel);
        mailTable.setName("mailTable"); // NOI18N
        mailTable.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(mailTable);

        javax.swing.GroupLayout mainPanelLayout = new javax.swing.GroupLayout(mainPanel);
        mainPanel.setLayout(mainPanelLayout);
        mainPanelLayout.setHorizontalGroup(
            mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 499, Short.MAX_VALUE)
        );
        mainPanelLayout.setVerticalGroup(
            mainPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 249, Short.MAX_VALUE)
        );

        menuBar.setName("menuBar"); // NOI18N

        org.jdesktop.application.ResourceMap resourceMap = org.jdesktop.application.Application.getInstance(swgmailparser.SWGMailParserApp.class).getContext().getResourceMap(SWGMailParserView.class);
        fileMenu.setText(resourceMap.getString("fileMenu.text")); // NOI18N
        fileMenu.setName("fileMenu"); // NOI18N

        javax.swing.ActionMap actionMap = org.jdesktop.application.Application.getInstance(swgmailparser.SWGMailParserApp.class).getContext().getActionMap(SWGMailParserView.class, this);
        openMenuItem.setAction(actionMap.get("opemMenuAction")); // NOI18N
        openMenuItem.setText(resourceMap.getString("openMenuItem.text")); // NOI18N
        openMenuItem.setName("openMenuItem"); // NOI18N
        fileMenu.add(openMenuItem);

        exitMenuItem.setAction(actionMap.get("quit")); // NOI18N
        exitMenuItem.setName("exitMenuItem"); // NOI18N
        fileMenu.add(exitMenuItem);

        menuBar.add(fileMenu);

        exportMenu.setText(resourceMap.getString("exportMenu.text")); // NOI18N
        exportMenu.setName("exportMenu"); // NOI18N

        exportCVSMenuItem.setAction(actionMap.get("exportCSVAction")); // NOI18N
        exportCVSMenuItem.setName("exportCVSMenuItem"); // NOI18N
        exportMenu.add(exportCVSMenuItem);

        menuBar.add(exportMenu);

        helpMenu.setText(resourceMap.getString("helpMenu.text")); // NOI18N
        helpMenu.setName("helpMenu"); // NOI18N

        aboutMenuItem.setAction(actionMap.get("showAboutBox")); // NOI18N
        aboutMenuItem.setName("aboutMenuItem"); // NOI18N
        helpMenu.add(aboutMenuItem);

        menuBar.add(helpMenu);

        statusPanel.setName("statusPanel"); // NOI18N

        statusPanelSeparator.setName("statusPanelSeparator"); // NOI18N

        statusMessageLabel.setName("statusMessageLabel"); // NOI18N

        statusAnimationLabel.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        statusAnimationLabel.setName("statusAnimationLabel"); // NOI18N

        progressBar.setName("progressBar"); // NOI18N

        javax.swing.GroupLayout statusPanelLayout = new javax.swing.GroupLayout(statusPanel);
        statusPanel.setLayout(statusPanelLayout);
        statusPanelLayout.setHorizontalGroup(
            statusPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(statusPanelSeparator, javax.swing.GroupLayout.DEFAULT_SIZE, 499, Short.MAX_VALUE)
            .addGroup(statusPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(statusMessageLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 329, Short.MAX_VALUE)
                .addComponent(progressBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(statusAnimationLabel)
                .addContainerGap())
        );
        statusPanelLayout.setVerticalGroup(
            statusPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(statusPanelLayout.createSequentialGroup()
                .addComponent(statusPanelSeparator, javax.swing.GroupLayout.PREFERRED_SIZE, 2, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(statusPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(statusMessageLabel)
                    .addComponent(statusAnimationLabel)
                    .addComponent(progressBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(3, 3, 3))
        );

        openFileChooser.setCurrentDirectory(new java.io.File("C:\\Program Files\\StarWarsGalaxies\\profiles"));
        openFileChooser.setFileSelectionMode(javax.swing.JFileChooser.FILES_AND_DIRECTORIES);
        openFileChooser.setMultiSelectionEnabled(true);
        openFileChooser.setName("openFileChooser"); // NOI18N

        saveFileChooser.setDialogType(javax.swing.JFileChooser.SAVE_DIALOG);
        saveFileChooser.setName("saveFileChooser"); // NOI18N

        setComponent(mainPanel);
        setMenuBar(menuBar);
        setStatusBar(statusPanel);
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem exportCVSMenuItem;
    private javax.swing.JMenu exportMenu;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable mailTable;
    private javax.swing.JPanel mainPanel;
    private javax.swing.JMenuBar menuBar;
    private javax.swing.JFileChooser openFileChooser;
    private javax.swing.JMenuItem openMenuItem;
    private javax.swing.JProgressBar progressBar;
    private javax.swing.JFileChooser saveFileChooser;
    private javax.swing.JLabel statusAnimationLabel;
    private javax.swing.JLabel statusMessageLabel;
    private javax.swing.JPanel statusPanel;
    // End of variables declaration//GEN-END:variables
    /*private final Timer messageTimer;
    private final Timer busyIconTimer;
    private final Icon idleIcon;
    private final Icon[] busyIcons = new Icon[ 15 ];
    private int busyIconIndex = 0;
    private JDialog aboutBox;*/
}
